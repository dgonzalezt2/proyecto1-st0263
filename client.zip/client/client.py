import httpx
import asyncio
import os
import grpc
import filetransfer_pb2
import filetransfer_pb2_grpc


async def initial_request(file_size: int):
    async with httpx.AsyncClient() as client:
        for attempt in range(3):
            response = await client.get(f'http://34.31.203.46/chunk-file?fileSizeInMb={file_size}')
            data = response.json()
            if 'error' not in data:
                return data
            else:
                print(f"Error en el intento {attempt + 1}: {data['error']}")
                if attempt < 2:
                    await asyncio.sleep(1)
        return data

async def success_request(file_name: str, chunk_size: int, chunk_number: int):
    payload = {
        "fileName": file_name,
        "chunkSize": chunk_size,
        "totalChunks": chunk_number
    }
    async with httpx.AsyncClient() as client:
        for attempt in range(3):
            # Usa json=payload para enviar los datos como JSON
            response = await client.post('http://34.31.203.46/update-file', json=payload)
            response_data = response.json()
            if 'error' not in response_data:
                return response_data
            else:
                print(f"Error en el intento {attempt + 1}: {response_data['error']}")
                if attempt < 2:
                    await asyncio.sleep(1)
        return response_data


def send_chunk(data_node: str, file_name: str, chunk_number: int, chunk_data: bytes):
    channel = grpc.insecure_channel(f'{data_node}:50051')
    stub = filetransfer_pb2_grpc.FileServiceStub(channel)
    response = stub.SendChunk(
        filetransfer_pb2.ChunkData(
            filename=file_name, chunk_number=chunk_number, chunk_data=chunk_data
        )
    )
    return response


async def main():
    file_name = input("Ingrese el nombre del archivo: ")
    try:
        file_size_mb = os.path.getsize(file_name) / 1_000_000
        partition_data = await initial_request(file_size_mb)

        if 'error' in partition_data:
            print(f"Error: {partition_data['error']}")
            return
        
        if partition_data['totalChunks'] == 0:
            print("Error en el calculo del particionamiento")
            return
        
        with open(file_name, "rb") as file:
            chunk_size = int(partition_data['chunkSize'] * 1_000_000)
            for data_node, chunk_array in partition_data['chunkDistribution'].items():
                for chunk in chunk_array:
                    offset = (chunk - 1) * chunk_size
                    file.seek(offset)

                    data = file.read(chunk_size)
                    
                    response = send_chunk(data_node, file_name, chunk, data)
                    print(f"Chunk {chunk} enviado, respuesta del servidor: {response}")
        
        response = await success_request(file_name, partition_data['chunkSize'], partition_data['totalChunks'])
        print(response)
    except FileNotFoundError:
        print("El archivo no existe.")
    except Exception as e:
        print(f"Ocurrió un error al abrir el archivo: {e}")

#     response = stub.RequestChunk(
#         filetransfer_pb2.ChunkRequest(filename=filename, chunk_number=chunk_number)
#     )
#     print(response)
#     with open("Llegue.png", "wb") as f:
#         f.write(response.chunk_data)


if __name__ == "__main__":
    # run()
    asyncio.run(main())

